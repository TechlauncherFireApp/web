from enum import Enum


class LoginResult(Enum):
    SUCCESS = 0
    FAIL = 1

from enum import Enum


class UserType(Enum):
    VOLUNTEER = 0
    ADMIN = 1
